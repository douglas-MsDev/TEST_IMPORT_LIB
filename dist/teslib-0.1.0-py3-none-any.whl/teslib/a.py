def test(x: int) -> int:
    print('OK, funcionou')
    return x + 1

